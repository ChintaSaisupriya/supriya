package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.Placement;

public interface PlacementDAOIface {
	
	String addPlacement(Placement p);
	String updatePlacement(Placement p);
	String deletePlacement(String companyName);
	List<Placement> showAllPlacement();
	
}

package com.virtusa.dao;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.model.Placement;

@Repository
public class PlacementDAOIfaceImpl implements PlacementDAOIface {
	@Autowired
	private SessionFactory sessionfactory;
	@Transactional
	@Override
	public String addPlacement(Placement p) {
		String a=null;
		a=(String)sessionfactory.getCurrentSession().save(p);
		String msg=null;
		if(a!=null) {
			msg="Saved placement succesfully !";
		}else {
			msg="Some problem Occured !";
		}
		return msg;
	}
	@Transactional
	@Override
	public String updatePlacement(Placement p) {
		sessionfactory.getCurrentSession().saveOrUpdate(p);
		return "placement updated";
	}
	@Transactional
	@Override
	public String deletePlacement(String companyName) {
		String res = null;
		System.out.println("delete dao");
	Session	session = sessionfactory.getCurrentSession();
	Placement t1 = (Placement) session.get(Placement.class,companyName);
	System.out.println(t1);
			if (t1 != null) {
				System.out.println("iffffffffffffffffff");
				session.delete(t1);
				System.out.println("deleted");
				res = "success";
			} else {
				res = "fail";
			}
			return res;
		}
	@Override
	public List<Placement> showAllPlacement() {
		// TODO Auto-generated method stub
		Query q= (Query) sessionfactory.openSession().createQuery("from Placement");
		List<Placement> allPlacements= q.list();
		return allPlacements;
	}	}
		

	

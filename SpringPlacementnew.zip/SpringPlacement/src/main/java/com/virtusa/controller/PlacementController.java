package com.virtusa.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.model.Placement;
import com.virtusa.service.PlacementServiceIface;

@Controller

public class PlacementController {
	@Autowired
	PlacementServiceIface placementserviceiface;
	@RequestMapping("/placementadd")
	public String takeToReg(Model m) {
		m.addAttribute("reg",new Placement());
		return "register";
	}
	
	@RequestMapping("/register")
	public String Register(@Valid @ModelAttribute("reg") Placement placement,BindingResult result) {
		if(result.hasErrors()) {
			return "register";
		}else {
			placementserviceiface.addPlacement(placement);
			return "success";
		}
	}
	@RequestMapping("/placementupdate")
	public String takeToReg1(Model m) {
		m.addAttribute("upd",new Placement());
		return "update";
	}
	@RequestMapping("/update")
	public String update(@Valid @ModelAttribute("upd") Placement placement,BindingResult result) {
		if(result.hasErrors()) {
			return "update";
		}else {
			placementserviceiface.updatePlacement(placement);
			return "successupdate";
		}
	}
	@RequestMapping("/placementdelete")
	public String takeToReg2(Model m) {
		m.addAttribute("del",new Placement());
		return "delete";
	}
	@RequestMapping("/delete")
	public String delete(@RequestParam("companyName") String companyName) {
		
			placementserviceiface.deletePlacement(companyName);
			return "successdelete";
	}
	@RequestMapping("/placementlist")
	public ModelAndView takeToReg3() {
		List<Placement> l=placementserviceiface.showAllPlacements();
		return new ModelAndView("showallmeetings","list",l);
	}
	
	
}

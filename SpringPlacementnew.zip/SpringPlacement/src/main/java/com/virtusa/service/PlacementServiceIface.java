package com.virtusa.service;

import java.util.List;

import com.virtusa.model.Placement;

public interface PlacementServiceIface {
	String addPlacement(Placement p);
	String updatePlacement(Placement p);
	String deletePlacement(String companyName);
	List<Placement> showAllPlacements();

}

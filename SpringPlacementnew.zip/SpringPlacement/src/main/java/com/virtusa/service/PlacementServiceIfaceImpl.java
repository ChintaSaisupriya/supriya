package com.virtusa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.dao.PlacementDAOIface;
import com.virtusa.model.Placement;
@Service
public class PlacementServiceIfaceImpl implements PlacementServiceIface {
	@Autowired
	PlacementDAOIface placementdaoiface;
	
	@Override
	public String addPlacement(Placement p) {
		// TODO Auto-generated method stub
		return placementdaoiface.addPlacement(p);
	}

	@Override
	public String updatePlacement(Placement p) {
		// TODO Auto-generated method stub
		return placementdaoiface.updatePlacement(p);
	}

	@Override
	public String deletePlacement(String companyName) {
		// TODO Auto-generated method stub
		return placementdaoiface.deletePlacement(companyName);
	}

	@Override
	public List<Placement> showAllPlacements() {
		// TODO Auto-generated method stub
		return placementdaoiface.showAllPlacement();
	}

	

}

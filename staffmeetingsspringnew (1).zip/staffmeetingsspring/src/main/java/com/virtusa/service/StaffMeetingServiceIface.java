package com.virtusa.service;

import java.util.Date;
import java.util.List;

import com.virtusa.model.StaffMeetings;

public interface StaffMeetingServiceIface {
	String addMeeting(StaffMeetings s);
	String updMeeting(StaffMeetings s);
	String delMeeting(String meetingtype);
	List<StaffMeetings> showAllmeetings();

}

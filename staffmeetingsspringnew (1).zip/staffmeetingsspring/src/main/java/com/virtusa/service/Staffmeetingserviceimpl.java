package com.virtusa.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.dao.StaffMeetingDao;
import com.virtusa.model.StaffMeetings;

@Service
public class Staffmeetingserviceimpl implements StaffMeetingServiceIface {
	@Autowired
	StaffMeetingDao staffmeeting;
	public String addMeeting(StaffMeetings s) {
		return staffmeeting.addMeeting(s);
	}
	public String updMeeting(StaffMeetings s) {
		// TODO Auto-generated method stub
		return staffmeeting.updMeeting(s);
	}
	public String delMeeting(String meetingtype) {
		// TODO Auto-generated method stub
		return staffmeeting.delMeeting(meetingtype);
	}
	public List<StaffMeetings> showAllmeetings() {
		// TODO Auto-generated method stub
		return staffmeeting.showAllmeetings();
	}


}

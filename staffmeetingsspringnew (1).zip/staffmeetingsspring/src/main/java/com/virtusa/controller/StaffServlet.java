package com.virtusa.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.model.StaffMeetings;
import com.virtusa.service.StaffMeetingServiceIface;

@Controller

public class StaffServlet {
	@Autowired
	StaffMeetingServiceIface staffmeetingiface;
	@RequestMapping("/meetingadd")
	public String takeToReg(Model m) {
		m.addAttribute("reg",new StaffMeetings());
		return "register";
	}
	@RequestMapping("/register")
	public String Register(@Valid @ModelAttribute("reg") StaffMeetings staffmeeting,BindingResult result) {
		if(result.hasErrors()) {
			return "register";
		}else {
			staffmeetingiface.addMeeting(staffmeeting);
			return "success";
		}
	}
	@RequestMapping("/meetingupdate")
	public ModelAndView takeToReg1(StaffMeetings s) {
		return new ModelAndView("update","upd",s);
	}
	@RequestMapping("/update")
	public String update(@ModelAttribute("upd") StaffMeetings s, Model m) {
		System.out.println("ju");
		System.out.println(s.getMeetingtype());
		String k=staffmeetingiface.updMeeting(s);
		
		if(k==null) {
			System.out.println("kkkkk");
			m.addAttribute("updated","not updated");
			return "update";
		}else {
			System.out.println("bsjch");
			m.addAttribute("updated","updated");
			return "successupdate";
		}
	}
	@RequestMapping("/meetingdelete")
	public String takeToReg2(Model m) {
		m.addAttribute("del",new StaffMeetings());
		return "delete";
	}
	@RequestMapping("/delete")
	public String delete(@RequestParam("meetingtype") String meetingtype) {
		staffmeetingiface.delMeeting(meetingtype);
			return "successdelete";
	}
	@RequestMapping("/showallmeetingsadmin")
	public ModelAndView takeToReg3() {
		List<StaffMeetings> l=staffmeetingiface.showAllmeetings();
		return new ModelAndView("showallmeetingsadmin","list",l);
	}
	
}

